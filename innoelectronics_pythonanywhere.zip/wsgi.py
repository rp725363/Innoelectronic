import os
import sys

# Ensure this directory is in the Python path
project_dir = os.path.dirname(os.path.abspath(__file__))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Set working directory to project directory for relative paths
os.chdir(project_dir)

# PythonAnywhere WSGI requires the callable to be named 'application'
from app import app as application
